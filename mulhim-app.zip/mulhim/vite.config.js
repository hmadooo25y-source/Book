import { defineConfig } from 'vite';

// base './' lets the build work from any GitHub Pages sub-path (user.github.io/repo/)
export default defineConfig({ base: './', build: { target: 'es2022' } });
