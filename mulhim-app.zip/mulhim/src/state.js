import { $ } from './utils.js';

export const state = { name: '', text: '', parts: [], data: null };

let xp = 0;
try { xp = Number(localStorage.getItem('mulhim_xp')) || 0; } catch {}

export const renderXp = () => { $('#xp').textContent = xp; };
export const addXp = (n) => {
  xp += n;
  try { localStorage.setItem('mulhim_xp', String(xp)); } catch {}
  renderXp();
};
