import './style.css';
import { $, esc } from './utils.js';
import { state, renderXp } from './state.js';
import { extractText, splitParts } from './files.js';
import { generate, getKey, setKey, getModel, setModel, MODELS } from './ai.js';
import { quiz, cards, match } from './games.js';

const app = $('#app');
let ctrl = null;

function home(msg = '') {
  app.innerHTML = `<div class="card"><h1>حوّل أي كتاب إلى لعبة 🎮</h1>
    <p>ارفع كتابك (PDF أو نص) وسيصنع Claude اختبارات وبطاقات وألعاباً تفاعلية من محتواه.</p>
    <label class="drop" for="f">📂 اختر ملف الكتاب<br><small>PDF · TXT · MD</small></label>
    <input id="f" type="file" accept=".pdf,.txt,.md,text/plain,application/pdf" hidden>
    <p class="center" style="margin:12px 0">— أو الصق النص مباشرة —</p>
    <textarea id="t" placeholder="الصق فصلاً أو مقالاً هنا..."></textarea>
    <button class="btn" id="go">ابدأ</button>
    <div id="msg" class="err-m center" role="alert">${esc(msg)}</div></div>`;
  $('#f').onchange = async (e) => {
    const f = e.target.files[0];
    if (!f) return;
    $('#msg').innerHTML = '<div class="spin"></div><p class="center">جارٍ قراءة الكتاب...</p>';
    try { state.name = f.name; state.text = await extractText(f); prep(); }
    catch (x) { home(x.message || 'تعذّرت قراءة الملف.'); }
  };
  $('#go').onclick = () => {
    const v = $('#t').value.trim();
    if (v.length < 200) return home('الصق نصاً أطول (200 حرف على الأقل).');
    state.name = 'نص'; state.text = v; prep();
  };
}

function prep() {
  state.parts = splitParts(state.text);
  if (state.parts.length < 2) return gen(0);
  app.innerHTML = `<div class="card"><h2>📖 ${esc(state.name)}</h2>
    <p>الكتاب طويل (${state.parts.length} جزءاً). اختر الجزء الذي تريد التدرّب عليه:</p>
    <select id="p" aria-label="الجزء">${state.parts.map((p, i) => `<option value="${i}">الجزء ${i + 1} — ${esc(p.slice(0, 50))}…</option>`).join('')}</select>
    <button class="btn" id="g">إنشاء الألعاب</button><button class="btn sec" id="b">رجوع</button></div>`;
  $('#g').onclick = () => gen(+$('#p').value);
  $('#b').onclick = () => home();
}

async function gen(i) {
  ctrl = new AbortController();
  app.innerHTML = `<div class="card center"><div class="spin"></div><h2>جارٍ تحويل الكتاب إلى ألعاب...</h2>
    <p>قد يستغرق ذلك نحو نصف دقيقة</p><button class="btn sec" id="cx">إلغاء</button></div>`;
  $('#cx').onclick = () => ctrl.abort();
  try {
    state.data = await generate(state.parts[i], ctrl.signal);
    hub();
  } catch (e) {
    home(e.name === 'AbortError' ? 'تم الإلغاء.' : e.message);
  }
}

function hub() {
  const d = state.data;
  app.innerHTML = `<div class="card"><h2>🎯 ${esc(d.title)}</h2><p>${esc(d.summary)}</p></div>
    <div class="grid">
      <button class="mode" data-m="q"><span class="e">🧠</span>اختبار<small>${d.mcq.length} سؤال</small></button>
      <button class="mode" data-m="t"><span class="e">⚡</span>صح أم خطأ<small>${d.tf.length} عبارة</small></button>
      <button class="mode" data-m="b"><span class="e">✏️</span>أكمل الفراغ<small>${d.blanks.length} جملة</small></button>
      <button class="mode" data-m="c"><span class="e">🃏</span>بطاقات<small>${d.cards.length} بطاقة</small></button>
      <button class="mode wide" data-m="m"><span class="e">🔗</span>لعبة المطابقة<small>صِل المصطلح بتعريفه</small></button>
    </div><button class="btn sec" id="nw">📚 كتاب آخر</button>`;
  const tf = d.tf.map((x) => ({ q: x.s, options: ['صح ✅', 'خطأ ❌'], answer: x.a ? 0 : 1, explain: x.explain }));
  const actions = {
    q: () => quiz(app, d.mcq, '🧠 اختبار', hub),
    t: () => quiz(app, tf, '⚡ صح أم خطأ', hub),
    b: () => quiz(app, d.blanks, '✏️ أكمل الفراغ', hub),
    c: () => cards(app, d.cards, hub),
    m: () => match(app, d.cards, hub),
  };
  app.querySelectorAll('.mode').forEach((b) => (b.onclick = () => actions[b.dataset.m]()));
  $('#nw').onclick = () => home();
}

function settings() {
  app.innerHTML = `<div class="card"><h2>⚙️ الإعدادات</h2>
    <p>يعمل التطبيق بالكامل في متصفحك. مفتاحك يُحفظ على جهازك فقط ويُرسل مباشرة إلى Anthropic، ولا يمر بأي خادم آخر.</p>
    <label for="k">مفتاح Anthropic API</label>
    <input id="k" type="password" autocomplete="off" placeholder="sk-ant-..." value="${esc(getKey())}">
    <label for="m" style="display:block;margin-top:10px">النموذج</label>
    <select id="m">${MODELS.map(([v, n]) => `<option value="${v}" ${v === getModel() ? 'selected' : ''}>${n}</option>`).join('')}</select>
    <button class="btn" id="sv">حفظ</button><button class="btn sec" id="bk">رجوع</button></div>`;
  $('#sv').onclick = () => { setKey($('#k').value); setModel($('#m').value); home(); };
  $('#bk').onclick = () => (state.data ? hub() : home());
}

$('#settings').onclick = settings;
renderXp();
getKey() ? home() : settings();
