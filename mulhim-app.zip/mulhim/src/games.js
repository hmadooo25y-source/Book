import { esc, shuffle, $ } from './utils.js';
import { addXp } from './state.js';

export function quiz(root, items, title, exit) {
  items = shuffle(items);
  if (!items.length) return exit();
  let i = 0, sc = 0, st = 0, best = 0;
  const show = () => {
    if (i >= items.length) {
      const pc = Math.round((sc / items.length) * 100);
      addXp(sc * 10);
      root.innerHTML = `<div class="card center"><div class="big">${pc >= 90 ? '🏆' : pc >= 60 ? '🎉' : '💪'}</div>
        <h1>${sc} / ${items.length}</h1><p>نسبتك ${pc}% · أفضل سلسلة صحيحة: ${best} 🔥<br>كسبت ${sc * 10} نقطة</p>
        <button class="btn" id="r">إعادة المحاولة</button><button class="btn sec" id="h">القائمة</button></div>`;
      $('#r').onclick = () => quiz(root, items, title, exit);
      $('#h').onclick = exit;
      return;
    }
    const it = items[i];
    const order = shuffle(it.options.map((_, k) => k));
    root.innerHTML = `<div class="card"><div class="top"><span>${title}</span><span>${i + 1}/${items.length} · 🔥 ${st}</span></div>
      <div class="bar"><i style="width:${(i / items.length) * 100}%"></i></div><div class="q">${esc(it.q)}</div>
      ${order.map((k) => `<button class="opt" data-k="${k}">${esc(it.options[k])}</button>`).join('')}<div id="fb"></div></div>`;
    root.querySelectorAll('.opt').forEach((b) => (b.onclick = () => {
      const ok = +b.dataset.k === it.answer;
      root.querySelectorAll('.opt').forEach((x) => { x.disabled = true; if (+x.dataset.k === it.answer) x.classList.add('ok'); });
      if (ok) { sc++; st++; best = Math.max(best, st); } else { b.classList.add('bad'); st = 0; }
      $('#fb').innerHTML = `<div class="ex">${ok ? '✅ أحسنت!' : '❌ إجابة خاطئة.'} ${esc(it.explain || '')}</div>
        <button class="btn" id="n">${i + 1 >= items.length ? 'النتيجة' : 'التالي'}</button>`;
      $('#n').onclick = () => { i++; show(); };
    }));
  };
  show();
}

export function cards(root, list, exit) {
  const cs = shuffle(list);
  if (!cs.length) return exit();
  let i = 0;
  const show = () => {
    const c = cs[i];
    root.innerHTML = `<div class="card"><div class="top"><span>🃏 بطاقات</span><span>${i + 1}/${cs.length}</span></div>
      <div class="bar"><i style="width:${((i + 1) / cs.length) * 100}%"></i></div>
      <button class="flip" id="fl" aria-label="اقلب البطاقة"><span class="fi"><span class="fc">${esc(c.front)}</span><span class="fc b">${esc(c.back)}</span></span></button>
      <p class="center">اضغط على البطاقة لقلبها</p>
      <div class="row"><button class="btn sec" id="pv">السابق</button><button class="btn" id="nx">${i + 1 >= cs.length ? 'إنهاء' : 'التالي'}</button></div></div>`;
    $('#fl').onclick = () => $('#fl').classList.toggle('on');
    $('#pv').onclick = () => { if (i > 0) { i--; show(); } };
    $('#nx').onclick = () => { if (i + 1 >= cs.length) { addXp(15); exit(); } else { i++; show(); } };
  };
  show();
}

export function match(root, list, exit) {
  const cs = shuffle(list).slice(0, 5);
  if (cs.length < 3) return exit();
  let sel = null, done = 0, miss = 0;
  const L = shuffle(cs.map((c, k) => ({ k, t: c.front })));
  const R = shuffle(cs.map((c, k) => ({ k, t: c.back })));
  const col = (arr, s) => arr.map((x) => `<button class="mt" data-s="${s}" data-k="${x.k}">${esc(x.t)}</button>`).join('');
  root.innerHTML = `<div class="card"><div class="top"><span>🔗 المطابقة</span><span id="ms">أخطاء: 0</span></div>
    <p>اختر مصطلحاً ثم تعريفه الصحيح.</p><div class="m"><div>${col(L, 'l')}</div><div>${col(R, 'r')}</div></div></div>`;
  root.querySelectorAll('.mt').forEach((b) => (b.onclick = () => {
    if (b.classList.contains('done')) return;
    if (b.dataset.s === 'l') {
      root.querySelectorAll('[data-s=l]').forEach((x) => x.classList.remove('sel'));
      b.classList.add('sel'); sel = b; return;
    }
    if (!sel) return;
    if (sel.dataset.k === b.dataset.k) {
      sel.classList.remove('sel'); sel.classList.add('done'); b.classList.add('done'); sel = null;
      if (++done === cs.length) {
        const g = Math.max(10, 50 - miss * 10);
        addXp(g);
        root.innerHTML = `<div class="card center"><div class="big">🎉</div><h1>أنهيت اللعبة!</h1><p>أخطاء: ${miss} · كسبت ${g} نقطة</p>
          <button class="btn" id="r2">العب مجدداً</button><button class="btn sec" id="h2">القائمة</button></div>`;
        $('#r2').onclick = () => match(root, list, exit);
        $('#h2').onclick = exit;
      }
    } else {
      miss++; $('#ms').textContent = 'أخطاء: ' + miss;
      b.classList.add('err'); setTimeout(() => b.classList.remove('err'), 500);
    }
  }));
}
