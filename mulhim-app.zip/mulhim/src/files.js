import * as pdfjs from 'pdfjs-dist';
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;

export const PART_SIZE = 9000;
export const MAX_FILE_MB = 30;

export async function extractText(file) {
  if (file.size > MAX_FILE_MB * 1024 * 1024) throw new Error(`حجم الملف أكبر من ${MAX_FILE_MB} ميغابايت.`);
  if (/\.pdf$/i.test(file.name)) {
    const pdf = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
    let out = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const c = await page.getTextContent();
      out += c.items.map((x) => x.str).join(' ') + '\n';
    }
    if (out.trim().length < 200) throw new Error('لا يحتوي الـ PDF على نص قابل للقراءة (قد يكون ممسوحاً ضوئياً).');
    return out;
  }
  return file.text();
}

export function splitParts(text) {
  const t = text.replace(/\s+/g, ' ').trim();
  const parts = [];
  for (let i = 0; i < t.length; i += PART_SIZE) parts.push(t.slice(i, i + PART_SIZE));
  return parts;
}
